import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class TrelloAPITest {
    private WebDriver driver;
    private WebDriverWait wait;

    @Before
    public void setup() {
        driver = prepareChromeDriver();

        wait = new WebDriverWait(driver, 7);
    }


    private WebDriver prepareChromeDriver() {
        File driverFile = new File("WebDriver.chrome.driver", "drivers\\chromedriver.exe");
        String pathToChromeDrive = driverFile.getAbsolutePath();
        System.setProperty("WebDriver.chrome.driver", pathToChromeDrive);
        return new ChromeDriver();
    }

    @Test
    public void startMainTest() throws InterruptedException {
        login();
        createBoard("Yeni Board");
        openBoard();
        createNewCard1();
        createNewCard2();
    }

    @After
    public void close() {
        driver.close();
    }

    private void login() {
        driver.get("https://trello.com/login");
        if (driver.findElements(By.id("user-password")).size() > 0) {
            driver.findElement(By.id("user-password")).click();
        }

        driver.findElement(By.id("user")).sendKeys("ibrahim.karaman@etiya.com");
        driver.findElement(By.id("password")).sendKeys("Aa123456!");
        driver.findElement(By.id("login")).submit();
    }

    private void createBoard(String name) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class=\"boards-page-board-section-list\"]/li/div/p/span[text()=\"Create new board\"]/../..")))
                .click();
        driver.findElement(By.xpath("//form[@class=\"create-board-form\"]/div[@class=\"form-container\"]/div[contains(@class,\"board-tile create-board-tile\")]/div/input[@class=\"subtle-input\"]"))
                .sendKeys(name);
        driver.findElement(By.xpath("//form[@class=\"create-board-form\"]/button[@class=\"primary\"]/span[text()=\"Create Board\"]"))
                .click();


    }

    private void openBoard() {
        WebElement boardHref = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='/ibrahimkaraman/boards']")));
            boardHref.click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='board-tile-details-name']//div[text()='Yeni board']")))
                .click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='board-wrapper']")));
    }

    private void createNewCard1() {
        driver.findElement(By.xpath("//a[@class='open-card-composer js-open-card-composer']"))
                .click();

        driver.findElement(By.xpath("//textarea[@class='list-card-composer-textarea js-card-title']"))
                .sendKeys("New Card1");

        driver.findElement(By.xpath("//input[@class='primary confirm mod-compact js-add-card']"))
                .click();
    }
    private void createNewCard2() {
        driver.findElement(By.xpath("//a[@class='open-card-composer js-open-card-composer']"))
                .click();
        driver.findElement(By.xpath("//textarea[@class='list-card-composer-textarea js-card-title']"))
                .sendKeys("New Card2");
        driver.findElement(By.xpath("//input[@class='primary confirm mod-compact js-add-card']"))
                .click();

    }

}
